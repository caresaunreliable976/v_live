This is a sample software payload for the quora-farmer test.
Test message from LO's farmer pipeline.
